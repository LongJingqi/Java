import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class PIS {
    public static void main(String[] args) throws IOException {
        readCorpus("wiki_data_samples", "input");
    }

    public static void readCorpus(String fileName, String inputName) throws IOException {
        File file = new File(fileName);
        File input = new File(inputName);
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        BufferedReader inputBuffer = new BufferedReader(new FileReader(input));
        String tempString;
        String inputString;
        double average = 0;
        ArrayList list = new ArrayList();
        int leastMatch = 50;
        int i, match;
        int line = 0;
        ArrayList list_input = new ArrayList();

        while ((tempString = bufferedReader.readLine()) != null) {
            list.add(tempString);
        }
        while ((inputString = inputBuffer.readLine()) != null) {
            String[] sentence = inputString.split("\\.|\\?|!");
            for (int j = 0; j < sentence.length; j++) {
                list_input.add(sentence[j]);
            }
        }


        for (int k = 0; k < list_input.size(); k++) {
            inputString = (String) list_input.get(k);
            if (inputString.length() < 50) {
                continue;
            }
            inputString = inputString.replaceAll(" ", "");
            i = 0;
            match = 0;
            line++;
            long startTime = System.currentTimeMillis();
            while (i + leastMatch <= inputString.length()) {
                for (int j = 0; j < list.size(); j++) {
                    tempString = (String) list.get(j);
                    tempString = tempString.replaceAll(" |\\.|\\?|!", "");
                    if (Sunday_Matcher(tempString, inputString.substring(i, i + leastMatch)).equals("has match")) {
//                    if (KMP_Matcher(tempString, inputString.substring(i, i + leastMatch)).equals("has match")) {
                        match++;
                        break;
                    }
                }
                i++;
            }
            long endTime = System.currentTimeMillis();

            average += (match * 100.00 / (inputString.length() + 1 - leastMatch));


            System.out.print("The sentence " + line + " similarity is : ");
            System.out.println(String.format("%.2f", (match * 100.00 / (inputString.length() + 1 - leastMatch)) > 0 ? match * 100.00 / (inputString.length() + 1 - leastMatch) : 0) + "%");
            System.out.println("Running Time is：" + (endTime - startTime) + "ms");
        }
        average = average / list_input.size();
        System.out.println("Total similarity is : " + String.format("%.2f", average) + "%");

        bufferedReader.close();
    }


    public static String naive_string_matcher(String corpus, String input) {
        int corpus_length = corpus.length();
        int input_length = input.length();
        for (int i = 0; i <= corpus_length - input_length; i++) {
            for (int j = 0; j < input_length; j++) {
                if (input.charAt(j) != corpus.charAt(i + j)) {
                    break;
                }
                if (j == input_length - 1)
                    return ("has match");
            }
        }
        return ("no match");
    }

    public static String KMP_Matcher(String corpus, String input) {
        int n = corpus.length();
        int m = input.length();
        int[] next = Compute_Prefix_Function(input);
        int q = 0;
        for (int i = 0; i < n; i++) {
            while (q > 0 && input.charAt(q) != corpus.charAt(i)) {
                q = next[q - 1];
            }
            if (input.charAt(q) == corpus.charAt(i)) {
                q++;
            }
            if (q == m) {
                return ("has match");
            }
        }
        return ("no match");

    }

    public static int[] Compute_Prefix_Function(String input) {
        int m = input.length();
        int[] next = new int[m];
        next[0] = 0;
        int k = 0;
        for (int q = 1; q < m; q++) {
            while (k > 0 && input.charAt(k) != input.charAt(q)) {
                k = next[k - 1];
            }
            if (input.charAt(k) == input.charAt(q)) {
                k++;
            }
            next[q] = k;
        }

        return next;
    }

    public static String Sunday_Matcher(String corpus, String input) {
        char[] destchars = corpus.toCharArray();
        char[] patternchars = input.toCharArray();
        int i = 0;
        int j = 0;
        while (i <= (corpus.length() - input.length() + j)) {
            if (destchars[i] != patternchars[j]) {
                if (i == (corpus.length() - input.length() + j)) { break; }
                int pos = contains(patternchars, destchars[i + input.length() - j]);
                if (pos == -1) {
                    i = i + input.length() + 1 - j;
                    j = 0;
                } else {
                    i = i + input.length() - pos - j;
                    j = 0;
                }
            } else {
                if (j == (input.length() - 1)) {
                    i = i - j + 1;
                    j = 0;
                    return "has match";
                } else {
                    i++;
                    j++;
                }
            }
        }
        return "no match";
    }

    public static int contains(char[] chars, char target) {
        for (int i = chars.length - 1; i >= 0; i--) {
            if (chars[i] == target) {
                return i;
            }
        }
        return -1;
    }
}