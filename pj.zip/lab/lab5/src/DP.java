import java.util.Scanner;

public class DP {
    public static void main(String[] args) {
        System.out.print("Please enter the number of jobs you want to process : ");
        Scanner scanner = new Scanner(System.in);
        int jobs = scanner.nextInt();
        int[] time = new int[jobs];
        int[] profit = new int[jobs];
        int[] deadline = new int[jobs];
        for (int i = 0; i < jobs; i++) {
            Scanner sc = new Scanner(System.in);
            time[i] = sc.nextInt();
            profit[i] = sc.nextInt();
            deadline[i] = sc.nextInt();
        }
        sortByDeadline(time, profit, deadline);
        int maxProfit = getMaxProfit(time, profit, deadline);
        System.out.println("The max profit you will get is : " + maxProfit);
    }

    public static void sortByDeadline(int[] time, int[] profit, int[] deadline) {
        int n = deadline.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1; j++) {
                if (deadline[j] > deadline[j + 1]) {
                    int temp = deadline[j];
                    deadline[j] = deadline[j + 1];
                    deadline[j + 1] = temp;
                    int tempTime = time[j];
                    time[j] = time[j + 1];
                    time[j + 1] = tempTime;
                    int tempProfit = profit[j];
                    profit[j] = profit[j + 1];
                    profit[j + 1] = tempProfit;
                }
            }
        }
    }

    public static int getMaxArrayElement(int[] array) {
        int max = array[0];
        int length = array.length;
        for (int i = 0; i < length; i++) {
            if (array[i] > max) {
                max = array[i];
            }
        }
        return max;
    }

    public static int getMaxProfit(int[] time, int[] profit, int[] deadline) {
        int number = time.length;
        int maxv = getMaxArrayElement(deadline);
        int[][] dp = new int[number + 1][maxv + 1];
        for (int i = 0; i <= number; i++)
            dp[i][0] = 0;
        for (int i = 0; i <= maxv; i++) {
            dp[0][i] = 0;
        }
        //TODO: dp[i][j] means first i objects put into the j-capacity pack
        for (int i = 1; i <= number; i++) {     //TODO: i is number of objects
            for (int j = 1; j <= deadline[i - 1]; j++) {    //TODO: j is capacity
                if (j < time[i - 1])
                    dp[i][j] = dp[i - 1][j];       //TODO: if time exceeds capacity which means it will not end by the deadline, then the pack cannot have more objects
                else
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - time[i - 1]] + profit[i - 1]);  //TODO: a->put but become less; b->capacity reduce time[i-1]
            }
            for (int j = deadline[i - 1] + 1; j <= maxv; j++) {
                dp[i][j] = dp[i][j - 1];
            }
        }
        return dp[number][maxv];
    }
}
