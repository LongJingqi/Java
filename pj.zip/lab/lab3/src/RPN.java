/**
 * Created by 36526 on 2017/9/27.
 */
public class RPN {
    public static void main(String[] args) {

    }
}
