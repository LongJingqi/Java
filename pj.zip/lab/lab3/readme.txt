Reverse Polish Notation
=======================


1. Your code should be able to generate RPN based on inputs, e.g. 1+1 should yield 1 1 +.



2. You should then be able to evaluate the RPN based on a stack, e.g. 
(1 1 + $, []) -> (1 + $, [1]) -> (+ $, [1, 1]) -> ($, [2])
`$' denotes the terminating character.



3. You can assume all inputs are valid, and no extra spaces will be present in the inputs.



4. You can assume all numbers involved are integers, no need to introduce real numbers.



5. You should expect 5 operators, `+' `-' `*' `/' and `mod', and the `/' and `mod' operators 
should together conform to the principle that: `a = (a/b) * b + a mod b', 
when a or b is negative, the quotient is expected to round to zero.
e.g., -5 / 7 is 0 instead of -1, thus -5 mod 7 should yield -5 (0 * 7 + (-5) == -5). 
This shouldn't be a problem if you are using gcc, but if you are using other platforms, check first.
If the `%' and `/' operators in your language suprise you, probably you cannot rely on the primitive 
ones and implement them yourself.



6. You are expected to deal with precedence properly, `+' and `-' have a lower precedence 
and `*', `/' and `mod' all have a higher precedence.  for an expression looks like `lhs op1 mid op2 rhs', 
the result should look like:
```
if precedence(op1) < precedence(op2):
  let v = op2(mid, rhs)
  return op1(lhs, v)
else:
  let v = op1(lhs, mid)
  return op2(v, rhs)
```
i.e., if the right operator binds tighter, you should evaluate it first, otherwise you should 
evaluate from left to right.



7. You should also deal with `()'s and `{}'s, they immediately bind your expression tight.



8. Some examples:
1+1     -> 2
    1+2*3   -> 7     
(1+2)*3 -> 9    
(2-3)/7 -> 0
    (-5)mod7-> -5 
   3/(-1)  -> -3
    3-2-1   -> 0   
9/3/3   -> 1    
9/{3/3} -> 9



9. You can assume that all inputs that I give you have matched parenthesis and braces,
I won't create difficulties for you on this minor issue.



10. If you are using scripting languages, `eval' or `exec' are not allowed. GLHF


Please upload your files to FTP, and emailing to TAs will not be accepted this time.


*The HARD deadline is 23:59:59, Sun, 2017/10/8*
