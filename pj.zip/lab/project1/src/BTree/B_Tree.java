package BTree;


import java.util.ArrayList;
import java.util.List;

public class B_Tree<T extends Comparable<T>> {
    private int degree;
    private BTNode rootNode = new BTNode();
    private int minKeyNum;
    private int maxKeyNum;

    public B_Tree(int degree) {
        this.degree = degree;
        this.maxKeyNum = 2 * degree - 1;
        this.minKeyNum = degree - 1;
    }

    public class BTNode<T extends Comparable<T>> {
        private int number = 0;
        private List<T> value = new ArrayList<T>();
        private List<T> key = new ArrayList<T>();
        private List<BTNode> children = new ArrayList<BTNode>();
        private boolean isLeaf = true;

        public T getKey(int index) {
            return key.get(index);
        }

        public T getValue(int index) {
            return value.get(index);
        }

        public BTNode getChildren(int index) {
            return children.get(index);
        }

        public void addValue(int index, T value) {
            this.value.add(index, value);
        }

        public void removeValue(int index) {
            value.remove(index);
        }

        public void addKey(int index, T key) {
            this.key.add(index, key);
            number++;
        }

        public void removeKey(int index) {
            key.remove(index);
            number--;
        }

        public void addChildren(int index, BTNode children) {
            this.children.add(index, children);
        }

        public void removeChildren(int index) {
            children.remove(index);
        }

        public boolean isFull() {
            return number == maxKeyNum;
        }

        public int getChildrenSize() {
            return children.size();
        }
    }

    private void splitNode(BTNode x, int index) {
        BTNode z = new BTNode();
        BTNode y = x.getChildren(index);
        z.isLeaf = y.isLeaf;
        for (int j = 0; j < minKeyNum; j++) {
            z.addKey(j, y.getKey(j + degree));
            z.addValue(j, y.getValue(j + degree));
        }
        if (!y.isLeaf) {
            for (int j = 0; j < degree; j++) {
                z.addChildren(j, y.getChildren(j + degree));
            }
            for (int j = maxKeyNum; j > minKeyNum; j--) {
                y.removeChildren(j);
            }
        }
        x.addChildren(index + 1, z);
        x.addKey(index, y.getKey(minKeyNum));
        x.addValue(index, y.getValue(minKeyNum));
        for (int j = maxKeyNum - 1; j > minKeyNum - 1; j--) {
            y.removeKey(j);
            y.removeValue(j);
        }
    }

    private void insertNonFull(BTNode x, T key, T value) {
        int i = x.number - 1;
        if (x.isLeaf) {
            while (i >= 0 && key.compareTo((T) x.getKey(i)) < 0) {
                i--;
            }
            x.addKey(i + 1, key);
            x.addValue(i + 1, value);
        } else {
            while (i >= 0 && key.compareTo((T) x.getKey(i)) < 0) {
                i--;
            }
            i++;
            if (x.getChildren(i).isFull()) {
                splitNode(x, i);
                if (key.compareTo((T) x.getKey(i)) > 0) i++;
            }
            insertNonFull(x.getChildren(i), key, value);
        }
    }

    public void insert(T key, T value) {
        BTNode root = this.rootNode;
        if (root.number == maxKeyNum) {
            BTNode s = new BTNode();
            this.rootNode = s;
            s.isLeaf = false;
            s.number = 0;
            s.addChildren(0, root);
            splitNode(s, 0);
            insertNonFull(s, key, value);
        } else insertNonFull(root, key, value);
    }

    private int predecessor(BTNode y) {
        BTNode x = y;
        int i = x.number;
        while (!x.isLeaf) {
            x = x.getChildren(i);
            i = x.number;
        }
        return i - 1;
    }

    private int successor(BTNode z) {
        BTNode x = z;
        while (!x.isLeaf) {
            x = x.getChildren(0);
        }
        return 0;
    }

    private T search(BTNode x, T key) {
        int i = 0;
        while (i < x.number && key.compareTo((T) x.getKey(i)) > 0) {
            i++;
        }
        if (i < x.number && key.compareTo((T) x.getKey(i)) == 0) {
            return (T) x.getKey(i);
        } else if (x.isLeaf) return null;
        else return search(x.getChildren(i), key);
    }

    public T search(T key) {
        return search(this.rootNode, key);
    }

    private void mergeNode(BTNode x, int index, BTNode y, BTNode z) {
        y.addKey(minKeyNum, x.getKey(index));
        y.addValue(minKeyNum, x.getValue(index));
        for (int j = 0; j < minKeyNum; j++) {
            y.addKey(degree + j, z.getKey(j));
            y.addValue(degree + j, z.getValue(j));
        }
        if (!y.isLeaf) {
            for (int j = 0; j < degree; j++) {
                y.addChildren(degree + j, z.getChildren(j));
            }
        }
        x.removeKey(index);
        x.removeValue(index);
        x.removeChildren(index + 1);
        z = null;
    }

    private void shiftToRightChild(BTNode x, int index, BTNode y, BTNode z) {
        z.addKey(0, x.getKey(index));
        z.addValue(0, x.getValue(index));
        x.removeKey(index);
        x.removeValue(index);
        x.addKey(index, y.getKey(y.number - 1));
        x.addValue(index, y.getValue(y.number - 1));
        if (!z.isLeaf) {
            z.addChildren(0, y.getChildren(y.number));
            y.removeChildren(y.number);
        }
        y.removeValue(y.number - 1);
        y.removeKey(y.number - 1);
    }

    private void shiftToLeftChild(BTNode x, int index, BTNode y, BTNode z) {
        y.addValue(y.number, x.getValue(index));
        y.addKey(y.number, x.getKey(index));
        x.removeKey(index);
        x.removeValue(index);
        x.addValue(index, z.getValue(0));
        x.addKey(index, z.getKey(0));
        if (!y.isLeaf) {
            y.addChildren(y.number, z.getChildren(0));
        }
        z.removeChildren(0);
        z.removeKey(0);
        z.removeValue(0);
    }

    private void deleteNoNone(BTNode x, T key) {
        int i = 0;
        //case1
        if (x.isLeaf) {
            while (i < x.number && key.compareTo((T) x.getKey(i)) > 0) {
                i++;
            }
            if (i < x.number && key.compareTo((T) x.getKey(i)) == 0) {
                x.removeKey(i);
            }
        } else {
            while (i < x.number && key.compareTo((T) x.getKey(i)) > 0) {
                i++;
            }
            BTNode y = x.getChildren(i);
            BTNode z = null;
            if (i < x.number) {
                z = x.getChildren(i + 1);
            }
            //case2
            if (i < x.number && key.compareTo((T) x.getKey(i)) == 0) {
                //case2a
                if (y.number > minKeyNum) {
                    T key_1 = (T) y.getKey(predecessor(y));
                    T value_1 = (T) y.getValue(predecessor(y));
                    deleteNoNone(y, key_1);
                    x.removeValue(i);
                    x.removeKey(i);
                    x.addValue(i, value_1);
                    x.addKey(i, key_1);
                }
                //case2b
                else if (z.number > minKeyNum) {
                    T key_2 = (T) z.getKey(successor(z));
                    T value_2 = (T) z.getValue(successor(z));
                    deleteNoNone(z, key_2);
                    x.removeValue(i);
                    x.removeKey(i);
                    x.addValue(i, value_2);
                    x.addKey(i, key_2);
                }
                //case 2c
                else {
                    mergeNode(x, i, y, z);
                    deleteNoNone(y, key);
                }

            }
            //case3
            else {
                BTNode p = null;
                if (i > 0) {
                    p = x.getChildren(i - 1);
                }
                if (y.number == minKeyNum) {
                    //case3a
                    if (i > 0 && p.number > minKeyNum) {
                        shiftToRightChild(x, i - 1, p, y);
                    } else if (i < x.number && z.number > minKeyNum) {
                        shiftToLeftChild(x, i, y, z);
                    }
                    //case3b
                    else if (i == x.number) {
                        mergeNode(x, i - 1, p, y);
                        y = p;
                    } else
                        mergeNode(x, i, y, z);
                }
                deleteNoNone(y, key);
            }
        }
    }

    public void delete(T key) {
        BTNode root = this.rootNode;
        if (root.number == 1 && root.getChildrenSize() == 0) {
            this.rootNode.removeValue(0);
            this.rootNode.removeKey(0);
        } else {
            if (root.number == 1) {
                BTNode y = root.getChildren(0);
                BTNode z = root.getChildren(1);
                if (y.number == minKeyNum && z.number == minKeyNum) {
                    mergeNode(root, 0, y, z);
                    this.rootNode = y;
                    root = null;
                    deleteNoNone(y, key);
                } else
                    deleteNoNone(root, key);
            }else deleteNoNone(root,key);
        }
    }

    private BTNode nodeSearch(BTNode x, T key) {
        int i = 0;
        while (i < x.number && key.compareTo((T) x.getKey(i)) > 0) {
            i++;
        }
        if (i < x.number && key.compareTo((T) x.getKey(i)) == 0) {
            return x;
        } else if (x.isLeaf)
            return null;
        else {
            return nodeSearch(x.getChildren(i), key);
        }
    }

    public BTNode keySearch(T key) {
        return nodeSearch(this.rootNode, key);
    }

    public int indexSearch(T key) {
        return indexSearch(this.rootNode, key);
    }

    private int indexSearch(BTNode x, T key) {
        int i = 0;
        while (i < x.number && key.compareTo((T) x.getKey(i)) > 0) {
            i++;
        }
        if (i < x.number && key.compareTo((T) x.getKey(i)) == 0) {
            return i;
        } else if (x.isLeaf)
            return -1;
        else {
            return indexSearch(x.getChildren(i), key);
        }
    }

    public void update(T key, T value) {
        if (search(key) == null) {
            insert(key, value);
        } else {
            BTNode node = keySearch(key);
            int index = indexSearch(key);
            node.removeValue(index);
            node.addValue(index, value);

        }
    }

    private void dump(BTNode node) {
        for (int i = 0; i < node.number; i++) {
            if (!node.isLeaf)
                dump(node.getChildren(i));
            System.out.println(node.getKey(i) + " " + node.getValue(i));
            if (!node.isLeaf)
                dump(node.getChildren(i + 1));
        }
    }

    public void dumpAll() {
        dump(this.rootNode);
    }
}