package RedBlackTree;

public class RB_Tree<T extends Comparable<T>> {
    private RBTNode<T> mRoot;
    private static final boolean RED = false;
    private static final boolean BLACK = true;

    public class RBTNode<T extends Comparable<T>> {
        T key;
        T meaning;
        RBTNode<T> left;
        RBTNode<T> right;
        RBTNode<T> parent;
        boolean color;

        public RBTNode(T key, T meaning, boolean color, RBTNode<T> parent, RBTNode<T> left, RBTNode<T> right) throws NullPointerException {
            this.key = key;
            this.meaning = meaning;
            this.color = color;
            this.parent = parent;
            this.left = left;
            this.right = right;
        }

        public T getMeaning() {
            return meaning;
        }

        public String toString() {
            return "" + key + "\n" + meaning + (this.color == RED ? "(R)" : "B");
        }
    }

    public RB_Tree() throws NullPointerException {
        mRoot = null;
    }

    private RBTNode<T> parentOf(RBTNode<T> node) {
        return node != null ? node.parent : null;
    }

    private boolean isRed(RBTNode<T> node) {
        return (node != null) && (node.color == RED);
    }

    private void setBlack(RBTNode<T> node) {
        if (node != null) node.color = BLACK;
    }

    private void setRed(RBTNode<T> node) {
        if (node != null) node.color = RED;
    }

    private void inOrder(RBTNode<T> tree) throws NullPointerException {
        if (tree != null) {
            inOrder(tree.left);
            System.out.println(tree.key + " " + tree.meaning);
            inOrder(tree.right);
        }
    }

    public void inOrder() throws NullPointerException {
        inOrder(mRoot);
    }

    private RBTNode<T> iterativeSearch(RBTNode<T> x, T key) throws NullPointerException {
        while (x != null) {
            int cmp = key.compareTo(x.key);
            if (cmp < 0) x = x.left;
            else if (cmp > 0) x = x.right;
            else return x;
        }
        return x;
    }

    public RBTNode<T> iterativeSearch(T key) throws NullPointerException {
        return iterativeSearch(mRoot, key);
    }

    private RBTNode<T> minimum(RBTNode<T> tree) {
        if (tree == null)
            return null;
        while (tree.left != null)
            tree = tree.left;
        return tree;
    }


    private void leftRotate(RBTNode<T> x) throws NullPointerException {
        RBTNode<T> y = x.right;
        x.right = y.left;
        if (y.left != null) y.left.parent = x;
        y.parent = x.parent;
        if (x.parent == null) this.mRoot = y;
        else if (x == x.parent.left) x.parent.left = y;
        else x.parent.right = y;
        y.left = x;
        x.parent = y;
    }

    private void rightRotate(RBTNode<T> y) throws NullPointerException {
        RBTNode<T> x = y.left;
        y.left = x.right;
        if (x.right != null) x.right.parent = y;
        x.parent = y.parent;
        if (y.parent == null) this.mRoot = x;
        else if (y == y.parent.right) y.parent.right = x;
        else y.parent.left = x;
        x.right = y;
        y.parent = x;
    }

    private void insertFixUp(RBTNode<T> z) throws NullPointerException {
        RBTNode<T> parent, gparent;
        while (((parent = parentOf(z)) != null) && isRed(parent)) { // 若“父节点存在，并且父节点的颜色是红色”
            gparent = parentOf(parent);
            if (parent == gparent.left) { //若“父节点”是“祖父节点的左孩子”
                RBTNode<T> uncle = gparent.right;
                if ((uncle != null) && isRed(uncle)) { // Case 1条件：叔叔节点是红色
                    setBlack(uncle);
                    setBlack(parent);
                    setRed(gparent);
                    z = gparent;
                    continue;
                }
                if (parent.right == z) { // Case 2条件：叔叔是黑色，且当前节点是右孩子
                    RBTNode<T> tmp;
                    leftRotate(parent);
                    tmp = parent;
                    parent = z;
                    z = tmp;
                }
                // Case 3条件：叔叔是黑色，且当前节点是左孩子
                setBlack(parent);
                setRed(gparent);
                rightRotate(gparent);
            } else { //若“z的父节点”是“z的祖父节点的右孩子”
                RBTNode<T> uncle = gparent.left;
                if ((uncle != null) && isRed(uncle)) { // Case 1条件：叔叔节点是红色
                    setBlack(uncle);
                    setBlack(parent);
                    setRed(gparent);
                    z = gparent;
                    continue;
                }
                if (parent.left == z) {  // Case 2条件：叔叔是黑色，且当前节点是左孩子
                    RBTNode<T> tmp;
                    rightRotate(parent);
                    tmp = parent;
                    parent = z;
                    z = tmp;
                }
                // Case 3条件：叔叔是黑色，且当前节点是右孩子
                setBlack(parent);
                setRed(gparent);
                leftRotate(gparent);
            }
        }
        setBlack(this.mRoot);
    }

    private void insert(RBTNode<T> z) throws NullPointerException {
        int cmp;
        RBTNode<T> y = null;
        RBTNode<T> x = this.mRoot;
        while (x != null) {
            y = x;
            cmp = z.key.compareTo(x.key);
            if (cmp < 0) x = x.left;
            else x = x.right;
        }
        z.parent = y;
        if (y != null) {
            cmp = z.key.compareTo(y.key);
            if (cmp < 0) y.left = z;
            else y.right = z;
        } else this.mRoot = z;
        z.left = null;
        z.right = null;
        z.color = RED;
        insertFixUp(z);
    }

    public void insert(T key, T meaning) throws NullPointerException {
        RBTNode<T> node = new RBTNode<T>(key, meaning, BLACK, null, null, null);
        if (node != null) insert(node);
    }

    public void update(T key, T meaning) throws NullPointerException {
        if (iterativeSearch(key) == null) insert(key, meaning);
        else {
            RBTNode<T> node = iterativeSearch(key);
            node.meaning = meaning;
        }
    }

    private void deleteFixUp(RBTNode<T> x) {
        while ((x != this.mRoot) && x.color == BLACK) {
            if (x == x.parent.left) {
                RBTNode<T> w = x.parent.right;
                if (w.color == RED) {
                    w.color = BLACK;
                    x.parent.color = RED;
                    leftRotate(x.parent);
                    w = x.parent.right;
                }
                if (w.left.color == BLACK && w.right.color == BLACK) {
                    w.color = RED;
                    x = x.parent;
                } else if (w.right.color == BLACK) {
                    w.left.color = BLACK;
                    w.color = RED;
                    rightRotate(w);
                    w = x.parent.right;
                }
                w.color = x.parent.color;
                x.parent.color = BLACK;
                w.right.color = BLACK;
                leftRotate(x.parent);
                x = this.mRoot;
            } else {
                RBTNode<T> w = x.parent.left;
                if (w.color == RED) {
                    w.color = BLACK;
                    x.parent.color = RED;
                    rightRotate(x.parent);
                    w = x.parent.left;
                }
                if (w.right.color == BLACK && w.left.color == BLACK) {
                    w.color = RED;
                    x = x.parent;
                } else if (w.left.color == BLACK) {
                    w.right.color = BLACK;
                    w.color = RED;
                    leftRotate(w);
                    w = x.parent.left;
                }
                w.color = x.parent.color;
                x.parent.color = BLACK;
                w.left.color = BLACK;
                rightRotate(x.parent);
                x = this.mRoot;
            }
        }
        x.color = BLACK;
    }

    private void transplant(RBTNode<T> u, RBTNode<T> v) {
        if (u.parent == null) this.mRoot = v;
        else if (u == u.parent.left) u.parent.left = v;
        else u.parent.right = v;
        // v.parent = u.parent;
        //存在null引用parent
    }

    private void delete(RBTNode<T> z) {
        RBTNode<T> x;
        RBTNode<T> y = z;
        RBTNode<T> replace = y;
        replace.color = y.color;
        if (z.left == null) {
            x = z.right;
            transplant(z, z.right);
        } else if (z.right == null) {
            x = z.left;
            transplant(z, z.left);
        } else {
            y = minimum(z.right);
            replace.color = y.color;
            x = y.right;
            if (y.parent == z) x.parent = y;
            else {
                transplant(y, y.right);
                y.right = z.right;
                y.right.parent = y;
            }
            transplant(z, y);
            y.left = z.left;
            y.left.parent = y;
            y.color = z.color;
        }
        if (replace.color == BLACK) deleteFixUp(z);
    }

    public void delete(T key) {
        RBTNode<T> node = iterativeSearch(mRoot, key);
        if (node != null) delete(node);
    }
    //另一种可行的delete方法
  /*  private void deleteFixUp(RBTNode<T> node, RBTNode<T> parent) {
        RBTNode<T> other;
        while ((node == null || isBlack(node)) && (node != this.mRoot)) {
            if (parent.left == node) {
                other = parent.right;
                if (isRed(other)) {
                    setBlack(other);
                    setRed(parent);
                    leftRotate(parent);
                    other = parent.right;
                }
                if ((other.left == null || isBlack(other.left)) &&
                        (other.right == null || isBlack(other.right))) {
                    setRed(other);
                    node = parent;
                    parent = parentOf(node);
                } else {
                    if (other.right == null || isBlack(other.right)) {
                        setBlack(other.left);
                        setRed(other);
                        rightRotate(other);
                        other = parent.right;
                    }
                    setColor(other, colorOf(parent));
                    setBlack(parent);
                    setBlack(other.right);
                    leftRotate(parent);
                    node = this.mRoot;
                    break;
                }
            } else {
                other = parent.left;
                if (isRed(other)) {
                    setBlack(other);
                    setRed(parent);
                    rightRotate(parent);
                    other = parent.left;
                }
                if ((other.left == null || isBlack(other.left)) &&
                        (other.right == null || isBlack(other.right))) {
                    setRed(other);
                    node = parent;
                    parent = parentOf(node);
                } else {
                    if (other.left == null || isBlack(other.left)) {
                        setBlack(other.right);
                        setRed(other);
                        leftRotate(other);
                        other = parent.left;
                    }
                    setColor(other, colorOf(parent));
                    setBlack(parent);
                    setBlack(other.left);
                    rightRotate(parent);
                    node = this.mRoot;
                    break;
                }
            }
        }
        if (node != null)
            setBlack(node);
    }

    private void delete(RBTNode<T> z) {
        RBTNode<T> child, parent;
        boolean color;
        if ((z.left != null) && (z.right != null)) {
            RBTNode<T> replace = z;
            replace = replace.right;
            while (replace.left != null)
                replace = replace.left;
            if (parentOf(z) != null) {
                if (parentOf(z).left == z)
                    parentOf(z).left = replace;
                else
                    parentOf(z).right = replace;
            } else {
                this.mRoot = replace;
            }
            child = replace.right;
            parent = parentOf(replace);
            color = colorOf(replace);
            if (parent == z) {
                parent = replace;
            } else {
                if (child != null)
                    setParent(child, parent);
                parent.left = child;
                replace.right = z.right;
                setParent(z.right, replace);
            }
            replace.parent = z.parent;
            replace.color = z.color;
            replace.left = z.left;
            z.left.parent = replace;
            if (color == BLACK)
                deleteFixUp(child, parent);
            z = null;
            return;
        }
        if (z.left != null) {
            child = z.left;
        } else {
            child = z.right;
        }
        parent = z.parent;
        color = z.color;
        if (child != null)
            child.parent = parent;
        if (parent != null) {
            if (parent.left == z)
                parent.left = child;
            else
                parent.right = child;
        } else {
            this.mRoot = child;
        }
        if (color == BLACK)
            deleteFixUp(child, parent);
        z = null;
    }

    public void delete(T key) {
        RBTNode<T> node;
        if ((node = iterativeSearch(mRoot, key)) != null)
            delete(node);
    }*/

}
