import RedBlackTree.RB_Tree;

import java.io.*;
import java.util.Scanner;

public class RBTDictionary {
    public static void main(String[] args) throws IOException, NullPointerException {
        RB_Tree rBtreeDictionary = new RB_Tree();
        Scanner scanner = new Scanner(System.in);
        String cmdline;


        while (true) {
            System.out.print("RBTDictionary > ");
            cmdline = scanner.nextLine();
            String[] cmd = cmdline.split(" ");
            if (cmd.length == 0)
                System.out.println("Error: no command");
            else {
                switch (cmd[0]) {
                    case "INSERT":
                        if (cmd.length == 3) {
                            if (rBtreeDictionary.iterativeSearch(cmd[1]) == null) {
                                rBtreeDictionary.insert(cmd[1], cmd[2]);
                                System.out.println("Success: INSERT " + cmd[1] + " " + cmd[2]);
                            } else System.out.println("Error: key conflict");
                        } else
                            System.out.println("Error: wrong command");
                        break;
                    case "PUT":
                        if (cmd.length == 3) {
                            rBtreeDictionary.update(cmd[1], cmd[2]);
                            System.out.println("Success: UPDATE " + cmd[1] + " " + cmd[2]);
                        } else
                            System.out.println("Error: wrong command");
                        break;
                    case "GET":
                        if (cmd.length == 2) {
                            RB_Tree.RBTNode node = rBtreeDictionary.iterativeSearch(cmd[1]);
                            if (node != null) {
                                System.out.println("Success: GET " + cmd[1] + " " + node.getMeaning());
                            } else
                                System.out.println("Error: key missing");
                        } else
                            System.out.println("Error: wrong command");
                        break;
                    case "DEL":
                        if (cmd.length == 2) {
                            if (rBtreeDictionary.iterativeSearch(cmd[1]) != null) {
                                rBtreeDictionary.delete(cmd[1]);
                                System.out.println("Success: delete " + cmd[1]);
                            } else System.out.println("Error: key missing");
                        } else
                            System.out.println("Error: wrong command");
                        break;
                    case "LOAD":
                        if (cmd.length == 2) {
                            BufferedReader bufferedReader = readFile(cmd[1]);
                            if (bufferedReader != null) {
                                String word = bufferedReader.readLine();
                                String wordChinese = bufferedReader.readLine();
                                while (word != null && wordChinese != null) {
                                    rBtreeDictionary.update(word, wordChinese);
                                    word = bufferedReader.readLine();
                                    wordChinese = bufferedReader.readLine();
                                }
                                bufferedReader.close();
                                System.out.println("Success: load " + cmd[1]);
                            } else
                                System.out.println("Error: cannot read " + cmd[1]);
                        } else
                            System.out.println("Error: wrong command");
                        break;
                    case "DUMP":
                        rBtreeDictionary.inOrder();
                        break;
                    case "EXIT":
                        System.exit(0);
                    default:
                        System.out.println("Error: wrong command");
                }
            }
        }
    }

    public static BufferedReader readFile(String filename) throws IOException {
        try {
            File file = new File(filename);
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            return bufferedReader;
        } catch (IOException e) {
            System.out.println("Error: IO Exception");
        }
        return null;
    }
}
