import chess
import random

board = chess.Board(fen='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1')

print board


def evaluate_board(board):
    score = 0
    pawnEvalWhite = [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                     [5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0],
                     [1.0, 1.0, 2.0, 3.0, 3.0, 2.0, 1.0, 1.0],
                     [0.5, 0.5, 1.0, 2.5, 2.5, 1.0, 0.5, 0.5],
                     [0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0],
                     [0.5, -0.5, -1.0, 0.0, 0.0, -1.0, -0.5, 0.5],
                     [0.5, 1.0, 1.0, -2.0, -2.0, 1.0, 1.0, 0.5],
                     [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
                     ]
    pawnEvalBlack = [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                     [0.5, 1.0, 1.0, -2.0, -2.0, 1.0, 1.0, 0.5],
                     [0.5, -0.5, -1.0, 0.0, 0.0, -1.0, -0.5, 0.5],
                     [0.0, 0.0, 0.0, 2.0, 2.0, 0.0, 0.0, 0.0],
                     [0.5, 0.5, 1.0, 2.5, 2.5, 1.0, 0.5, 0.5],
                     [1.0, 1.0, 2.0, 3.0, 3.0, 2.0, 1.0, 1.0],
                     [5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0, 5.0],
                     [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
                     ]
    knightEval = [[-5.0, -4.0, -3.0, -3.0, -3.0, -3.0, -4.0, -5.0],
                  [-4.0, -2.0, 0.0, 0.0, 0.0, 0.0, -2.0, -4.0],
                  [-3.0, 0.0, 1.0, 1.5, 1.5, 1.0, 0.0, -3.0],
                  [-3.0, 0.5, 1.5, 2.0, 2.0, 1.5, 0.5, -3.0],
                  [-3.0, 0.0, 1.5, 2.0, 2.0, 1.5, 0.0, -3.0],
                  [-3.0, 0.5, 1.0, 1.5, 1.5, 1.0, 0.5, -3.0],
                  [-4.0, -2.0, 0.0, 0.5, 0.5, 0.0, -2.0, -4.0],
                  [-5.0, -4.0, -3.0, -3.0, -3.0, -3.0, -4.0, -5.0]
                  ]
    bishopEvalWhite = [[-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0],
                       [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0],
                       [-1.0, 0.0, 0.5, 1.0, 1.0, 0.5, 0.0, -1.0],
                       [-1.0, 0.5, 0.5, 1.0, 1.0, 0.5, 0.5, -1.0],
                       [-1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, -1.0],
                       [-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0],
                       [-1.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.5, -1.0],
                       [-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0]
                       ]
    bishopEvalBlack = [[-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0],
                       [-1.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.5, -1.0],
                       [-1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0],
                       [-1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, -1.0],
                       [-1.0, 0.5, 0.5, 1.0, 1.0, 0.5, 0.5, -1.0],
                       [-1.0, 0.0, 0.5, 1.0, 1.0, 0.5, 0.0, -1.0],
                       [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0],
                       [-2.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -2.0]
                       ]
    rookEvalWhite = [[0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                     [0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [0.0, 0.0, 0.0, 0.5, 0.5, 0.0, 0.0, 0.0]
                     ]
    rookEvalBlack = [[0.0, 0.0, 0.0, 0.5, 0.5, 0.0, 0.0, 0.0],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [-0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.5],
                     [0.5, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.5],
                     [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
                     ]
    evalQueen = [[-2.0, -1.0, -1.0, -0.5, -0.5, -1.0, -1.0, -2.0],
                 [-1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0],
                 [-1.0, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -1.0],
                 [-0.5, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -0.5],
                 [0.0, 0.0, 0.5, 0.5, 0.5, 0.5, 0.0, -0.5],
                 [-1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.0, -1.0],
                 [-1.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, -1.0],
                 [-2.0, -1.0, -1.0, -0.5, -0.5, -1.0, -1.0, -2.0]
                 ]
    kingEvalWhite = [[-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-2.0, -3.0, -3.0, -4.0, -4.0, -3.0, -3.0, -2.0],
                     [-1.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -1.0],
                     [2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0],
                     [2.0, 3.0, 1.0, 0.0, 0.0, 1.0, 3.0, 2.0]
                     ]
    kingEvalBlack = [[2.0, 3.0, 1.0, 0.0, 0.0, 1.0, 3.0, 2.0],
                     [2.0, 2.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0],
                     [-1.0, -2.0, -2.0, -2.0, -2.0, -2.0, -2.0, -1.0],
                     [-2.0, -3.0, -3.0, -4.0, -4.0, -3.0, -3.0, -2.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0],
                     [-3.0, -4.0, -4.0, -5.0, -5.0, -4.0, -4.0, -3.0]
                     ]

    for pieces in board.piece_map():
        piece = board.piece_at(pieces).symbol()
        if piece == "p" or piece == "P":
            score += (10 + (pawnEvalBlack[(63 - pieces) / 8][7 - ((63 - pieces) % 8)] if piece == "p"  else
                            pawnEvalWhite[(63 - pieces) / 8][7 - ((63 - pieces) % 8)])) * (1 if piece == "P" else -1)
        elif piece == "n" or piece == "N":
            score += (30 + knightEval[(63 - pieces) / 8][7 - ((63 - pieces) % 8)]) * (1 if piece == "N" else -1)
        elif piece == "b" or piece == "B":
            score += (30 + (bishopEvalBlack[(63 - pieces) / 8][7 - ((63 - pieces) % 8)] if piece == "b"  else
                            bishopEvalWhite[(63 - pieces) / 8][7 - ((63 - pieces) % 8)])) * (1 if piece == "B" else -1)
        elif piece == "r" or piece == "R":
            score += (50 + (rookEvalBlack[(63 - pieces) / 8][7 - ((63 - pieces) % 8)] if piece == "r"  else
                            rookEvalWhite[(63 - pieces) / 8][7 - ((63 - pieces) % 8)])) * (1 if piece == "R" else -1)
        elif piece == "q" or piece == "Q":
            score += (90 + evalQueen[(63 - pieces) / 8][7 - ((63 - pieces) % 8)]) * (1 if piece == "Q" else -1)
        elif piece == "k" or piece == "K":
            score += (900 + (kingEvalBlack[(63 - pieces) / 8][7 - ((63 - pieces) % 8)] if piece == "k"  else
                             kingEvalWhite[(63 - pieces) / 8][7 - ((63 - pieces) % 8)])) * (1 if piece == "K" else -1)

    return score


def alpha_beta_prunning(board, depth, alpha, beta, color):
    if depth == 0 or board.is_game_over(False):
        return evaluate_board(board) * (1 if color else -1)
    legal_moves = board.legal_moves
    if color:
        v = -9999
        for move in legal_moves:
            board.push(move)
            tmp_v = alpha_beta_prunning(board, depth - 1, alpha, beta, not color)
            v = max(v, tmp_v)
            board.pop()
            alpha = max(alpha, v)
            if beta <= alpha:
                return v
        return v
    else:
        v = 9999
        for move in legal_moves:
            board.push(move)
            tmp_v = alpha_beta_prunning(board, depth - 1, alpha, beta, not color)
            v = min(v, tmp_v)
            board.pop()
            beta = min(beta, v)
            if beta <= alpha:
                return v
        return v


def getBestMove(board, depth, color):
    legal_moves = board.legal_moves
    bestMoveValue = -9999 if color else 9999
    bestMove = chess.Move.null()
    for move in legal_moves:
        board.push(move)
        score = alpha_beta_prunning(board, depth - 1, -10000, 10000, not color)
        board.pop()
        if color:
            if bestMoveValue <= score:
                bestMoveValue = score
                bestMove = move
                return bestMove
        else:
            if bestMoveValue >= score:
                bestMoveValue = score
                bestMove = move
                return bestMove


def respond_to(board):
    bestMove = getBestMove(board, 3, board.turn)
    board.push(bestMove)
    return board


while not board.is_game_over(False):
    print respond_to(board)


# print(str((list(board.legal_moves))))
