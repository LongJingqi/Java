import chess

board = chess.Board(fen="rnb1k2r/ppp2ppp/5n2/3q4/1b1P4/2N5/PP3PPP/R1BQKBNR b KQkq - 3 7")
board.push(chess.Move.from_uci("h8g8"))
print board


def evaluate_board(board):
    def evaluate_board(board):
        score = 0
        for piece in board.board_fen():
            if piece == "p" or piece == "P":
                score = score + (-10 if piece == "p"  else 10)
            elif piece == "n" or piece == "N":
                score = score + (-30 if piece == "n"  else 30)
            elif piece == "b" or piece == "B":
                score = score + (-30 if piece == "b"  else 30)
            elif piece == "r" or piece == "R":
                score = score + (-50 if piece == "r"  else 50)
            elif piece == "q" or piece == "Q":
                score = score + (-90 if piece == "q"  else 90)
            elif piece == "k" or piece == "K":
                score = score + (-900 if piece == "k"  else 900)

        return score

print evaluate_board(board)
