//
// Created by 36526 on 2017/10/12.
//

#include <iostream>
#include "HashTable.h"
#include <ctime>
#include <cstdlib>


using namespace std;
const int length = 110;
const int number = 100;
const string firstname[10] = {"赵", "钱", "孙", "李", "周", "吴", "郑", "王", "韩", "杨"};
const string lastname[10] = {"欣", "娅", "宇", "智鹏", "嘉怡", "思源", "昊", "奇", "利民", "建国"};


int main() {
    HashTable hashTable[length];
    string name[number];
    long long studentnumber[number];
    string gender[number];
    int age[number];
    long long phonenumber[number];

    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10; ++j) {
            name[i * 10 + j] = firstname[i] + lastname[j];
            studentnumber[i * 10 + j] = 16302010000 + i * 10 + j;
            gender[i * 10 + j] = (i >= 5) ? "女" : "男";
            age[i * 10 + j] = 20;
            phonenumber[i * 10 + j] = 18718279182 + i * 123 + j * 12;
        }
    }
    for (int k = 0; k < length; k++) {
        hashTable[k].keyname = NULLKEY;
    }
    for (int i = 0; i < number; i++) {
        hashTable->insertHash(hashTable, name[i], studentnumber[i], gender[i], age[i], phonenumber[i]);
    }


    clock_t start, finish;
    start = clock();

    for (int j = 0; j < number; j++) {
        hashTable->searchHash(hashTable, name[j]);
    }
    finish = clock();
    cout << "Running time is: " << (double) (finish - start) / CLOCKS_PER_SEC << "s" << endl;

}