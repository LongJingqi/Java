//
// Created by 36526 on 2017/10/12.
//

#ifndef LAB4_HASHTABLE_H
#define LAB4_HASHTABLE_H
#define NULLKEY "null"
#define DELKEY "deleted"
const int eleLen = 110;
const int eleNum = 100;
const double load = 1.0 * eleNum / eleLen;

#include <cstdlib>
#include <string>

using namespace std;


class HashTable {
public:
    string keyname;    //the key of the hash table
    long long student_number;
    string gender;
    int age;
    long long phone_number;

    int hashFunction(string name);

    int doubleHash(int key, int length);

    int hash(string name, int i);

    int insertHash(HashTable hashTable[], string name, long long student_number, string gender, int age,
                   long long phone_number);

    int deleteHash(HashTable hashTable[], string name);

    int searchHash(HashTable hashTable[], string name);
};

int HashTable::hashFunction(string name) {
    int GBindex = 0;
    for (unsigned int i = 0; i < name.length() / 3; i++) {
        string GBword = name.substr(3 * i, 3);
        GBindex += ((unsigned char) GBword.at(0) - 176) * 94 + (unsigned char) GBword.at(1) - 161;
    }
    return GBindex;
}


int HashTable::doubleHash(int key, int length) {
    return (1 + key % (length - 1));
}

int HashTable::hash(string name, int i) {
    int key = hashFunction(name);
    int adr = (key + i * doubleHash(key, eleLen)) % (eleLen - 1);
    return adr;
}

int HashTable::insertHash(HashTable *hashTable, string name, long long student_number, string gender, int age,
                          long long phone_number) {
    int i = 0;
    do {
        int j = hash(name, i);
        if (hashTable[j].keyname == NULLKEY || hashTable[j].keyname == DELKEY) {
            hashTable[j].keyname = name;
            hashTable[j].student_number = student_number;
            hashTable[j].gender = gender;
            hashTable[j].age = age;
            hashTable[j].phone_number = phone_number;
            return j;
        } else i++;
    } while (i < eleLen);
    return -1;
}

int HashTable::searchHash(HashTable *hashTable, string name) {
    int i = 0;
    do {
        int j = hash(name, i);
        if (hashTable[j].keyname == name) {
            return j;
        } else i++;
    } while (hashTable[hash(name, i)].keyname != NULLKEY && i <= 1 / (1 - load));
    return -1;
}

int HashTable::deleteHash(HashTable *hashTable, string name) {
    int i = searchHash(hashTable, name);
    if (i == -1) {
        return -1;
    } else {
        hashTable[i].keyname = DELKEY;
        hashTable[i].student_number = 0;
        hashTable[i].gender = nullptr;
        hashTable[i].age = 0;
        hashTable[i].phone_number = 0;
        return 0;
    }
}


#endif //LAB4_HASHTABLE_H
